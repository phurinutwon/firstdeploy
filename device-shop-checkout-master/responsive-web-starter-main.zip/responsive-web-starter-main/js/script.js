// Add some interactivity to the website
console.log("Hello, world!");
